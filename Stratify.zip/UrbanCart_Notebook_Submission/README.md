Open `UrbanCart_Price_Optimization.ipynb` and run all cells from top to bottom.

The notebook starts from the five supplied CSV files and demonstrates the complete competition workflow:

1. data audit and cleaning;
2. consolidation into a daily SKU-level analytical dataset;
3. leakage-safe feature engineering;
4. focused exploratory analysis;
5. category and SKU elasticity estimation;
6. Q1 2025 baseline forecasting;
7. mispricing identification;
8. constrained SKU-level price optimization;
9. revenue, gross-profit, margin-rate and volume simulation; and
10. limitations and implementation recommendations.

## Run locally

```bash
cd UrbanCart_Notebook_Submission
python3 -m pip install -r requirements.txt
jupyter notebook UrbanCart_Price_Optimization.ipynb
```

Then select **Run All**. Generated files are written to `outputs/`.

## Input treatment

- Historical estimation data: January 2022-December 2024.
- Simulation period: January-March 2025.
- Promotions: actual supplied Q1 2025 promotion calendar.
- Competitor and inventory inputs: matching SKU/ISO-week Q1 2024 proxies because 2025 files were not supplied.

## Expected generated outputs

- `urbancart_clean_analytical_dataset.csv`
- `data_dictionary.csv`
- `category_elasticity.csv`
- `sku_elasticity.csv`
- `q1_2025_forecast_panel.csv`
- `price_recommendations.csv`
- `simulation_overall.csv`
- `simulation_by_category.csv`
- `model_diagnostics.json`

The results are modeled counterfactuals and should be validated through controlled pricing tests before implementation.
